from distutils.core import setup

setup(
    name="Oreo",
    version="0.1dev",
    packages=['oreo',],
    license='MIT License',
    long_description=open('README.md').read(),
)
    
